package com.example.kobar;

import android.content.res.Resources;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class SpotAdapter extends RecyclerView.Adapter<SpotAdapter.SpotViewHolder> {
    ArrayList<Spots> spots;


    public SpotAdapter(ArrayList<Spots> spots) {
        this.spots = spots;
    }

    @NonNull
    @Override
    public SpotAdapter.SpotViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        return new SpotViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.spots_layout,parent,false));
    }

    @Override
    public void onBindViewHolder(@NonNull SpotAdapter.SpotViewHolder holder, int position) {
        Spots theSpot=spots.get(position);
        holder.txtName.setText(spots.get(position).name);
        holder.txtRating.setText(spots.get(position).rating);
        holder.txtContact.setText(spots.get(position).contact);
        holder.txtAddress.setText(spots.get(position).address);

        Resources res=holder.itemView.getContext().getResources();
        int id=res.getIdentifier("@drawable/"+theSpot.cover,"drawable", "com.example.kobar");
        holder.imgcover.setImageResource(id);


    }

    @Override
    public int getItemCount() {
        return spots.size();
    }

    public class SpotViewHolder extends RecyclerView.ViewHolder {
        TextView txtName, txtRating,txtContact, txtAddress;
        ImageView imgcover;
        public SpotViewHolder(@NonNull View itemView) {
            super(itemView);
            txtName=itemView.findViewById(R.id.txtName);
            txtRating=itemView.findViewById(R.id.txtRating);
            txtContact=itemView.findViewById(R.id.txtContact);
            txtAddress=itemView.findViewById(R.id.txtAddress);
            imgcover=itemView.findViewById(R.id.imgCover);
        }
    }
}

