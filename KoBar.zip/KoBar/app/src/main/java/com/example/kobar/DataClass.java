package com.example.kobar;

public class DataClass {
    private String name;
    private String mobile;
    private String address;
    private String nic;
    private String user;

    public DataClass(String name, String mobile, String address, String nic, String user) {
        this.name = name;
        this.mobile = mobile;
        this.address = address;
        this.nic = nic;
        this.user = user;
    }

    public String getName() {
        return name;
    }

    public String getMobile() {
        return mobile;
    }

    public String getAddress() {
        return address;
    }

    public String getNic() {
        return nic;
    }

    public String getUser() {
        return user;
    }

    public DataClass(){

    }
}
