package com.example.kobar;

import static java.nio.charset.StandardCharsets.UTF_8;

import android.content.Context;

import androidx.annotation.NonNull;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.util.ArrayList;

public class Spots {
    String name;
    String rating;
    String contact;
    String address;
    String cover;

    public Spots(String name, String rating, String contact, String address, String cover) {
        this.name = name;
        this.rating = rating;
        this.contact = contact;
        this.address = address;
        this.cover = cover;

    }
    @NonNull
    static ArrayList<Spots> getSpots(String fileName, Context context){

        ArrayList<Spots> spotList=new ArrayList<>();
        try{
            InputStream inputStream=context.getAssets().open(fileName);

            byte[] buffer=new byte[inputStream.available()];
            inputStream.read(buffer);
            inputStream.close();


            //JSONObject json=new JSONObject(new String(buffer), StandardCharsets.UTF_8));
            JSONObject json=new JSONObject(new String(buffer,UTF_8));
            JSONArray spots=json.getJSONArray("spots");

            for(int i=0;i<spots.length();i++){
                spotList.add(new Spots(
                                spots.getJSONObject(i).getString("Name"),
                                spots.getJSONObject(i).getString("Rating"),
                                spots.getJSONObject(i).getString("Contact"),
                                spots.getJSONObject(i).getString("Address"),
                                spots.getJSONObject(i).getString("Cover")
                        )

                );
            }
        }
        catch (Exception e){
            e.printStackTrace();
        }
        return spotList;
    }

}
