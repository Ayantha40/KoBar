package com.example.kobar;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.FirebaseDatabase;

public class SignUp extends AppCompatActivity {


    private FirebaseAuth auth;
    private TextInputEditText signupEmail, signupPassword, signupAddress, signupNIC, signupContact, signupConfirmPassword, signupName ;
    private Button signupButton;
    private TextView txtsignin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        NetworkConnectivityUtil networkConnectivityUtil = new NetworkConnectivityUtil(this);
        networkConnectivityUtil.startNetworkMonitoring();


        auth = FirebaseAuth.getInstance();
        signupEmail = findViewById(R.id.txtEmail);
        signupPassword = findViewById(R.id.txtPassword);
        signupName = findViewById(R.id.txtname);
        signupAddress = findViewById(R.id.txtaddress);
        signupNIC = findViewById(R.id.txtnic);
        signupContact = findViewById(R.id.txtcontact);
        signupConfirmPassword = findViewById(R.id.txtPasswordConfirm);
        signupButton = findViewById(R.id.btnSignUp);




        signupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String user = signupEmail.getText().toString().trim();
                String pass = signupPassword.getText().toString().trim();
                String ageString = signupNIC.getText().toString();
                String name = signupName.getText().toString();
                String address = signupAddress.getText().toString();
                int age = Integer.parseInt(ageString);

                if(TextUtils.isEmpty(signupName.getText())){
                    signupName.setError("Name cannot be Empty");
                }
                else if (user.isEmpty()) {
                    signupEmail.setError("Email cannot be empty");
                }
                else if(TextUtils.isEmpty(signupAddress.getText())){
                    signupAddress.setError("Address cannot be Empty");
                }
                else if(TextUtils.isEmpty(signupNIC.getText())){
                    signupNIC.setError("Age cannot be Empty");
                }
                else if(age < 21){
                    signupNIC.setError("You are Underage !!");
                }
                else if (pass.isEmpty()) {
                    signupPassword.setError("Password cannot be empty");
                }
                else if (!pass.equals(signupConfirmPassword.getText().toString())){
                    signupConfirmPassword.setError("Passwords Mismatch");
                }
                else {
                    auth.createUserWithEmailAndPassword(user, pass).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                        @Override
                        public void onComplete(@NonNull Task<AuthResult> task) {
                            if (task.isSuccessful()) {
                                Toast.makeText(SignUp.this, "SignUp Successful", Toast.LENGTH_SHORT).show();
                                uploadData();
                                startActivity(new Intent(SignUp.this, Dashboard.class));
                            } else {
                                Toast.makeText(SignUp.this, "SignUp Failed" + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
                }

                txtsignin = findViewById(R.id.txtsignin);

                txtsignin.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View view) {
                        Intent SignIn = new Intent(getApplicationContext(), Login.class);
                        startActivity(SignIn);
                    }
                });
            }
        });
    }

    private void uploadData() {
        String name = signupName.getText().toString();
        String mobile = signupContact.getText().toString();
        String address = signupAddress.getText().toString();
        String nic = signupNIC.getText().toString();
        String user = FirebaseAuth.getInstance().getCurrentUser().getUid();

        DataClass dataClass = new DataClass(name,mobile,address,nic,user);

        FirebaseDatabase.getInstance().getReference("Users").child(name).setValue(dataClass).addOnCompleteListener(new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful()){
                    Toast.makeText(SignUp.this, "", Toast.LENGTH_SHORT).show();
                    finish();
                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getApplicationContext(),e.getMessage().toString(),Toast.LENGTH_SHORT).show();
            }
        });
    }
}
