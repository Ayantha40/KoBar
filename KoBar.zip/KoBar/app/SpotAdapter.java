public class SpotAdapter {
}
